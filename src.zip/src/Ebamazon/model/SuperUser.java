package Ebamazon.model;

public class SuperUser extends User {
}
