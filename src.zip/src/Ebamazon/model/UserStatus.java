package Ebamazon.model;

public enum UserStatus {
    GU,
    OU,
    SU
}
